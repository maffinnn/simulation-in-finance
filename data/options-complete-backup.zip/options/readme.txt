Downloaded on 2023-11-07
LONZA price: 331.30
SIKA price: 226.30

WARNING: 13/9 is empty, so used 12/9 to replace
There is a description for every maturity date, can use dropna to remove
Some rows have 0, might want to remove

Settings: strikes 10
As of: Date of product estimation date

Temporary Bloomberg storage file path: C:\Users\TANG0455\AppData\Local\Temp\Bloomberg\data

9/8
10/8
11/8
14/8 (start from here, deleted lonn, sika, remained grid1 and another)
15/8
16/8
17
18
21
22
23
24/8
25
28
29
30
31/8

Sep
1
4
5
6
7
8
11
12
13
14
15
18
19
20
21
22
25
26
27
28
29

Oct
2
3
4
5
6
9
10
11
12
13
16
17
18
19
20
23
24
25
26
27
30
31

Nov
1
2
3
6 (CSV)
7
8
9