Downloaded on 2023-11-07
LONZA price: 331.30
SIKA price: 226.30

There is a description for every maturity date, can use dropna to remove
Some rows have 0, might want to remove